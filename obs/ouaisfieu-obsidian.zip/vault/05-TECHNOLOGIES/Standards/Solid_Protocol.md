---
title: "Solid Protocol"
aliases: [Solid, Pod, Social Linked Data]
tags: [technologie, standard, donnees, souverainete]
created: 2026-02-03
createur: Tim Berners-Lee
---

# Solid Protocol

> *Protocole de decentralisation des donnees personnelles permettant aux utilisateurs de controler leurs propres informations.*

## Definition

Solid (Social Linked Data) est un projet initie par Tim Berners-Lee (inventeur du World Wide Web) au MIT, visant a re-decentraliser le web en donnant aux utilisateurs le controle de leurs donnees.

## Concept Central : Le Pod

```
POD PERSONNEL (Personal Online Datastore)

- Donnees de sante
- Donnees financieres
- Donnees professionnelles
- Donnees sociales
- Contributions ECP

Controle d'acces granulaire
Interoperabilite (Linked Data)
```

### Principes
1. Separation donnees/applications — Les donnees restent chez l'utilisateur
2. Controle d'acces — L'utilisateur decide qui accede a quoi
3. Portabilite — Changement de fournisseur sans perte de donnees
4. Interoperabilite — Standards ouverts (RDF, Linked Data)

## Partenaires Belges

### Paradigm (Bruxelles)
| Attribut | Valeur |
|----------|--------|
| Region | Bruxelles-Capitale |
| Fonction | Gestionnaire de donnees regional |
| Projet | Infrastructure Solid pour les citoyens bruxellois |
| Statut ECP | Allie potentiel 3/5 |

### Athumi (Flandre)
| Attribut | Valeur |
|----------|--------|
| Region | Flandre |
| Fonction | Gestionnaire de donnees regional |
| Projet | Deploiement Solid a grande echelle |
| Statut ECP | Allie potentiel 3/5 |

## Application a l'ECP

### Cas d'Usage
Le Pod Solid permettrait aux contributeurs ECP de :

1. Stocker leurs contributions de maniere souveraine
2. Prouver leur activite sans dependre d'un tiers
3. Partager selectivement avec SDA, ONSS, INAMI
4. Conserver l'historique pour le provisionnement differe

## Standards Techniques

| Standard | Fonction |
|----------|----------|
| RDF | Format de donnees liees |
| WebID | Identite decentralisee |
| WAC | Controle d'acces web |
| LDP | Linked Data Platform |

## Avantages pour l'ECP

| Avantage | Description |
|----------|-------------|
| Souverainete | Le contributeur controle ses donnees |
| Tracabilite | Historique complet et verifiable |
| Interoperabilite | Communication avec administrations |
| Perennite | Independance vis-a-vis des plateformes |
| Vie privee | Partage minimal et cible |

## Defis

| Defi | Mitigation |
|------|------------|
| Complexite technique | Interfaces utilisateur simplifiees |
| Adoption lente | Partenariat avec Paradigm/Athumi |
| Interoperabilite admin | Standards [[FHIR]] pour sante |
| Formation utilisateurs | Ateliers d'education numerique |

## Voir Aussi

- [[FHIR]]
- [[Paradigm]]
- [[Athumi]]
- [[MOC Technologies]]
- [[MOC ECP]]

## Sources

- solidproject.org
- Tim Berners-Lee — Articles et conferences
- Paradigm.brussels
- Athumi.be

---

#technologie #standard #donnees #souverainete #solid

[[MOC Technologies]] | [[HOME]]
