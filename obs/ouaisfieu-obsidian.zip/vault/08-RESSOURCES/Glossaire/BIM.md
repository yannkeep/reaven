---
title: "BIM"
aliases: [Beneficiaire Intervention Majoree, Statut BIM, Omnio]
tags: [glossaire, social, sante, statut, precarite]
created: 2026-02-03
---

# BIM — Beneficiaire de l'Intervention Majoree

> *Statut social ouvrant droit a des remboursements de soins de sante plus eleves et a divers avantages sociaux.*

## Definition

Le statut BIM (anciennement OMNIO ou VIPO) est accorde par les mutuelles belges aux personnes a revenus modestes. Il permet :

- Remboursements majores des soins de sante
- Ticket moderateur reduit ou supprime
- Acces aux tarifs sociaux (energie, transports, telecom)
- Reductions diverses (culture, loisirs, logement social)

## Conditions d'Acces

### Categories Automatiques
Certaines personnes obtiennent le BIM automatiquement :
- Beneficiaires du RIS (revenu d'integration sociale)
- Beneficiaires de la GRAPA
- Enfants handicapes (allocation familiale majoree)
- Mineurs etrangers non accompagnes

### Condition de Revenus
Pour les autres, le statut est accorde si les revenus bruts imposables du menage ne depassent pas un plafond (indexe annuellement) :

| Composition menage | Plafond annuel (indicatif) |
|-------------------|---------------------------|
| Isole | 24 000 EUR |
| Menage | 32 000 EUR |
| + par personne a charge | 4 500 EUR |

## Le Probleme : L'Effet Falaise

> [!danger] PIEGE INSTITUTIONNEL
> La perte du BIM au premier euro au-dessus du plafond cree un taux marginal effectif superieur a 100%.

### Mecanisme
```
Revenus = plafond - 1 EUR    BIM = OUI    Avantages 2000 EUR/an
Revenus = plafond + 1 EUR    BIM = NON    Perte TOTALE avantages
```

### Consequences
Gagner 1 EUR de plus peut faire perdre :
| Avantage perdu | Cout annuel |
|----------------|-------------|
| Tarifs sociaux energie | 500-1000 EUR |
| Remboursements sante | 200-500 EUR |
| Reductions transports | 100-300 EUR |
| Autres | Variable |
| TOTAL | Plus de 1000 EUR /an |

## Impact sur l'ECP

### Le Blocage
Le statut BIM est incompatible avec tout revenu supplementaire, meme minime. Cela bloque toute tentative de contribution citoyenne remuneree.

### La Solution ECP
Le mecanisme de provisionnement differe vise a :
1. Ne pas generer de revenu immediat
2. Accumuler la valeur dans une SRL
3. Distribuer APRES sortie du statut precaire
4. Maintenir le BIM pendant la contribution

### Validation Necessaire
Le ruling fiscal doit confirmer que le provisionnement n'est pas un revenu au sens fiscal et social.

## Chiffres

| Indicateur | Valeur |
|------------|--------|
| Beneficiaires BIM en Belgique | 2 millions |
| % population | 17% |
| Economie moyenne/beneficiaire | 800 EUR/an |

## Alternatives Discutees

### Suppression des Effets de Seuil
Remplacement du systeme binaire par une progressivite :
- Reduction graduelle des avantages
- Pas de perte brutale
- Taux marginal inferieur a 100%

### Statut Contributeur
Creation d'un statut specifique pour les contributions citoyennes :
- Compatible avec le BIM
- Plafond type volontariat
- Reconnaissance sociale

## Voir Aussi

- [[Piege Institutionnel]]
- [[ECP]]
- [[INAMI]]
- [[MOC Crises Sociales]]

---

#glossaire #social #sante #statut #precarite #bim

[[MOC Ressources]] | [[HOME]]
