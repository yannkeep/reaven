# OUAISFIEU — Vault Obsidian

## Base de Connaissances pour l'Intelligence Citoyenne Belge

Ce vault Obsidian contient l'ensemble du corpus documentaire du projet Ouaisfieu :
- Veille citoyenne belge
- Analyse du systeme politique
- Cartographie des crises sociales
- Strategie de financement
- Documentation technique (Solid, FHIR, Decidim)
- Projet ECP (Economie Contributive Provisionnee)

## Demarrage Rapide

1. Ouvrir ce dossier comme vault dans Obsidian
2. Commencer par 00-INDEX/HOME.md
3. Activer le snippet CSS ouaisfieu-theme.css dans les parametres
4. Explorer via le graphe ou les MOCs (Map of Content)

## Structure

```
00-INDEX/          Navigation et MOCs
01-BELGIQUE/       Systeme politique belge
02-CRISES/         Problematiques sociales
03-ACTEURS/        Cartographie des acteurs
04-FINANCEMENTS/   Sources et opportunites
05-TECHNOLOGIES/   Stack et outils
06-ECP/            Economie Contributive
08-RESSOURCES/     Glossaire, sources, templates
09-JOURNAL/        Notes de veille quotidiennes
```

## Tags

- #belgique : Systeme politique
- #crises : Problematiques sociales
- #acteur : Personnes et organisations
- #financement : Sources de financement
- #technologie : Outils et standards
- #ecp : Economie Contributive
- #MOC : Map of Content

## Theme

Le snippet CSS ouaisfieu-theme.css applique une palette :
- Vert tendre (#7fff7f) : Accent principal
- Lilas (#c9a0dc) : Accent secondaire
- Fond sombre (#0a0a0f) : Background

## Licence

CC BY-NC 4.0 (Creative Commons Attribution - Non Commercial)

## Contact

- Email : souad.effek@ouaisfi.eu
- Bluesky : @ouaisfi.eu
- Site : https://ouaisfi.eu

---

Don't be evil, just do it. - GPTPardi
