---
title: "FGTB"
aliases: [Federation Generale du Travail de Belgique, ABVV]
tags: [acteur, syndicat, allie, social]
created: 2026-02-03
position: ally
power: 4
type: syndicat
---

# FGTB — Federation Generale du Travail de Belgique

> *Syndicat socialiste belge, pilier du front commun syndical contre les reformes Arizona.*

## Identite

| Attribut | Valeur |
|----------|--------|
| Nom complet | Federation Generale du Travail de Belgique |
| Neerlandais | ABVV (Algemeen Belgisch Vakverbond) |
| Fondation | 1898 |
| President | Thierry Bodson |
| Affiliation | Pilier Socialiste |
| Membres | 1,5 million (avec CSC et CGSLB) |

## Position sur les Enjeux

### Reformes Arizona
Opposition ferme
- Contre la [[Limitation Chomage 24 Mois]]
- Contre les [[Sanctions Malades]]
- Denonce le demantelement du modele social

### ECP
Allie potentiel
- Services juridiques disponibles
- Expertise droit social
- Capacite de mobilisation

### Actions Menees
- Manifestation nationale 28 avril 2025
- Co-requerant [[Recours Article 23]]
- Front commun avec [[CSC]] et CGSLB

## Pouvoir et Influence

4/5

### Forces
- Capacite de mobilisation nationale
- Services d'etudes economiques
- Expertise juridique
- Reseau territorial dense

### Limites
- Pas d'acces direct aux cabinets Arizona
- Opposition a la coalition = moins d'influence directe

## Strategie d'Approche ECP

### Angle
> L'ECP offre une voie de sortie du piege institutionnel SANS perdre les protections syndicales.

### Interlocuteurs
- Service d'etudes FGTB
- Permanents regionaux (Bruxelles, Wallonie)
- Commission chomage

### Ressources Mobilisables
- Accompagnement juridique des contributeurs ECP
- Relais communication (journal Syndicats)
- Validation label social

## Voir Aussi

- [[CSC]] — Partenaire front commun
- [[Solidaris]] — Mutualite affiliee
- [[MOC Acteurs]]

## Contact

- Site : fgtb.be
- President : Thierry Bodson

---

#acteur #syndicat #allie #social #fgtb

[[MOC Acteurs]] | [[HOME]]
