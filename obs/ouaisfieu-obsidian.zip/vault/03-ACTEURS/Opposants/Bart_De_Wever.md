---
title: "Bart De Wever"
aliases: [De Wever, BDW]
tags: [acteur, opposant, politique, nva, arizona]
created: 2026-02-03
position: opponent
power: 5
type: politique
parti: N-VA
fonction: Premier Ministre
---

# Bart De Wever

> *Premier Ministre de Belgique (2025-), president de la N-VA, architecte ideologique de la coalition Arizona.*

## Identite

| Attribut | Valeur |
|----------|--------|
| Fonction | Premier Ministre de Belgique |
| Parti | N-VA (Nieuw-Vlaamse Alliantie) |
| Naissance | 21 decembre 1970, Mortsel |
| Formation | Historien (KU Leuven) |
| Parcours | Bourgmestre d'Anvers (2013-2024) |

## Positionnement Ideologique

### Economique
- Orthodoxie budgetaire
- Reduction de la dette publique
- Activation des chomeurs et malades
- Le travail doit payer plus que l'inactivite

### Institutionnel
- Confederalisme belge a terme
- Autonomie flamande maximale
- Critique des transferts Nord-Sud

### Social
- Responsabilisation individuelle
- Conditionnalite des aides
- Critique du modele social belge juge insoutenable

## Position sur les Enjeux

### Reformes Sociales
Architecte principal
- [[Limitation Chomage 24 Mois]] — Mesure phare
- [[Sanctions Malades]] — Responsabilisation
- Objectif 80% taux d'emploi

### ECP
Opposition probable
- Mefiance envers les statuts hybrides
- Priorite a l'emploi classique
- Scepticisme sur l'innovation sociale

### Mais...
Angle possible
> L'ECP valorise le travail et transforme des depenses passives en investissement actif — langage Arizona-compatible.

## Pouvoir et Influence

5/5

### Forces
- Premier Ministre = pouvoir executif maximal
- Autorite sur la N-VA (premier parti flamand)
- Communicateur efficace
- Discipline de parti stricte

### Limites
- Coalition a 5 partis = compromis necessaires
- Vooruit (Vandenbroucke) peut freiner sur le social
- Recours constitutionnels en cours

## Citations Notables

> Il faut avoir le courage de faire des reformes impopulaires.

> Le travail doit toujours etre plus remunerateur que l'inactivite.

## Strategie vis-a-vis de l'ECP

### Ce qui NE marchera PAS
- Appel a la solidarite
- Critique frontale du gouvernement
- Positionnement anti-systeme

### Ce qui POURRAIT marcher
- Argument economique : 21 Md EUR - investissement
- Alignement avec l'objectif 80% emploi
- Valorisation du travail (meme atypique)
- Reduction des depenses passives

### Interlocuteurs Preferables
- [[Frank Vandenbroucke]] (Vooruit) — Plus receptif
- [[Maxime Prevot]] (Engages) — Sensibilite sociale
- Pas d'approche directe de De Wever

## Voir Aussi

- [[Coalition Arizona]]
- [[Frank Vandenbroucke]]
- [[MOC Acteurs]]

---

#acteur #opposant #politique #nva #arizona

[[MOC Acteurs]] | [[HOME]]
