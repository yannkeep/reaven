---
title: "SDA"
aliases: [Service des Decisions Anticipees, Ruling fiscal, DVB]
tags: [acteur, institution, neutre, cible, juridique]
created: 2026-02-03
position: neutral
power: 5
type: administration
---

# SDA — Service des Decisions Anticipees

> *Autorite fiscale belge habilitee a delivrer des rulings securisant juridiquement des montages fiscaux innovants.*

## Identite

| Attribut | Valeur |
|----------|--------|
| Nom complet | Service des Decisions Anticipees |
| Neerlandais | DVB (Dienst Voorafgaande Beslissingen) |
| Tutelle | SPF Finances |
| Creation | 2002 (reforme 2014) |
| Base legale | Loi du 24 decembre 2002 |

## Fonction

Le SDA delivre des decisions anticipees (rulings) qui :
- Valident ou invalident un montage fiscal AVANT sa mise en oeuvre
- Engagent l'administration fiscale sur 5 ans
- Securisent juridiquement les porteurs de projets

### Types de Rulings
1. Ruling classique — Interpretation de la loi fiscale
2. Ruling anti-abus — Validation absence de fraude (Art. 344)
3. Ruling investissement — Avantages fiscaux specifiques

## Position Cle pour l'ECP

> [!important] CIBLE PRINCIPALE
> Le SDA est la seule autorite capable de securiser juridiquement le mecanisme de provisionnement differe.

### Enjeu du Ruling ECP
| Question | Reponse Attendue |
|----------|------------------|
| Le provisionnement differe est-il un revenu ? | NON (investissement) |
| L'article 344 (anti-abus) s'applique-t-il ? | NON (finalite sociale) |
| La [[Loi Volontariat 2005]] s'applique-t-elle ? | OUI (cadre compatible) |

## Pouvoir et Influence

5/5

### Forces
- Decision contraignante pour l'administration
- Expertise technique pointue
- Procedure etablie et previsible

### Limites
- Ne peut creer de droit nouveau
- Interprete uniquement la loi existante
- Peut refuser de statuer

## Procedure de Ruling

1. Depot dossier
2. Analyse recevabilite (2 semaines)
3. Instruction (2-4 mois)
4. Decision (3-6 mois total)

Si favorable : Ruling 5 ans
Si defavorable : Recours possible
Si refus de statuer : Autre voie

### Cout
Gratuit (service public)

## Strategie d'Approche ECP

### Elements du Dossier
1. Description precise du mecanisme ECP
2. Demonstration de l'alignement avec objectifs Arizona
3. Argumentation provisionnement different de revenu immediat
4. Requete validation absence d'abus (Art. 344)

### Arguments Cles
> Le provisionnement differe n'est pas un revenu mais un investissement social. Il ne vise pas l'optimisation fiscale personnelle mais la contribution au bien commun.

### Risques
| Risque | Mitigation |
|--------|------------|
| Refus de statuer | Reformuler la question |
| Ruling defavorable | Recours Conseil d'Etat |
| Delai excessif | Relances, pression politique |

## Timeline ECP

| Date | Action |
|------|--------|
| T1 2026 | Depot Ruling SDA |
| T2-T3 2026 | Instruction |
| T4 2026 | Decision attendue |
| 2027 | Recours si defavorable |

## Voir Aussi

- [[SPF Finances]]
- [[Article 344 CIR 92]]
- [[ECP]]
- [[MOC ECP]]

## Contact

- Site : ruling.be
- Adresse : Boulevard du Roi Albert II 33, 1030 Bruxelles

---

#acteur #institution #neutre #cible #juridique #ruling

[[MOC Acteurs]] | [[MOC ECP]] | [[HOME]]
