---
title: "MOC Financements"
aliases: [Financement, Subventions, Budget]
tags: [MOC, financement, subventions, europeen, fondations]
created: 2026-02-03
---

# MOC Financements

> *Un ecosysteme riche de financements accessibles, meme sans structure juridique formelle.*

## Sans Structure Juridique

### Hebergement Fiscal
- [[FRB Compte de Projet]] — Associations de fait acceptees, 18 mois max
- [[Fonds Democratie Loterie]] — 500 319 EUR distribues en 2025 (18 projets)

### Facturation Immediate
- [[SMart Belgium]] — 35 000 membres, 6.5% frais, protection sociale

### Crowdfunding
| Plateforme | Frais | Specificite |
|------------|-------|-------------|
| [[Open Collective]] | 0-10% | Hebergement fiscal, transparence |
| [[Liberapay]] | 3% | Dons recurrents, ethique |
| [[Growfunding]] | Faibles | Belge, matchfunding VGC |

### Transfrontalier Accessible
- [[Interreg Grande Region]] — 30 000 EUR, 90% cofin., structures informelles OK

## Avec Structure ASBL

### Europeen — Montants Eleves
| Programme | Montant | Deadline |
|-----------|---------|----------|
| [[Interreg FWV Micro-projets]] | 50 000 EUR (100%) | 19/01/2026 |
| [[Erasmus Plus KA210]] | 30-60 000 EUR | 05/03/2026 |
| [[CERV]] | 75-300 000 EUR | Variable |

### Bruxelles
- [[Innoviris PYSI]] — 100 000 EUR a 100%, innovation sociale
- [[Appel Participation Bruxelles]] — 10 000 EUR/2 ans

### FWB — Contexte Contraint
> [!warning] Moratoire 2026-2028
> Gel des nouvelles reconnaissances en [[Education Permanente]]

- [[Appels PCI]] — 5 000-35 000 EUR, citoyennete et interculturalite

## Fondations Privees

### Belgique
| Fondation | Focus | Montant |
|-----------|-------|---------|
| [[Fondation Roi Baudouin]] | 180 appels/an | Variable |
| [[Fondation Bernheim]] | Valeurs civiques 12-25 ans | Rolling |
| [[Cera]] | 700 projets/an | Variable |

### Europeen
| Fonds | Focus | Montant |
|-------|-------|---------|
| [[Civitates]] | Democratie, civic space | 10 M EUR distribues |
| [[Digital Freedom Fund]] | Contentieux droits numeriques | 45 000 EUR |

## Prix et Concours

| Prix | Montants | Theme |
|------|----------|-------|
| [[EUSIC]] | 75k / 50k / 25k EUR | Innovation sociale |
| [[Gitcoin Grants]] | Quadratic funding | 67 M USD distribues |

## Plan d'Action Recommande

### Immediat (1-3 mois)
- [ ] Contacter [[SAW-B]] ou [[Propage-s]]
- [ ] S'inscrire a [[SMart Belgium]]
- [ ] Rejoindre [[Civic Lab Brussels]]
- [ ] Candidater [[FRB Compte de Projet]]

### Court terme (3-6 mois)
- [ ] Creer l'ASBL (175 EUR)
- [ ] [[Appel Participation Bruxelles]] 2026
- [ ] [[Erasmus Plus KA210]] (deadline 05/03/2026)

## Liens Connexes

**Projet** : [[MOC Ouaisfieu]]
**Strategie** : [[MOC ECP]]
**Retour** : [[HOME]]

---

#financement #subventions #europeen #fondations #crowdfunding #asbl
