---
title: "MOC Crises Sociales"
aliases: [Crises, Precarite, Urgence Sociale]
tags: [MOC, crises, social, precarite, chomage, sante]
created: 2026-02-03
---

# MOC Crises Sociales

> *978 000 personnes maintenues dans l'inactivite contrainte. Cout : 21-24 milliards EUR/an.*

## Le Piege Institutionnel

> [!danger] Paradoxe Central
> Le systeme INDEMNISE l'inactivite totale mais PENALISE toute tentative de contribution.
> Taux marginal superieur a 100% : chaque euro gagne fait perdre le statut [[BIM]].

- [[Piege Institutionnel]] — Analyse du blocage systemique
- [[Taux Marginal Effectif]] — Pourquoi rester inactif est rationnel
- [[Violence Administrative]] — Complexite, delais, sanctions

## Chomage

### Reforme Arizona
- [[Limitation Chomage 24 Mois]] — Fin de l'assurance illimitee
- [[Vague 2 Exclusions Chomage]] — 90 000 personnes au 01/03/2026
- [[Basculement vers CPAS]] — 30 122 personnes immediates
- [[Recours Article 23]] — Principe de standstill

### Profils Concernes
- [[Chomeurs Longue Duree]] — Majoritairement 50-55 ans
- [[Ex-travailleurs Industriels]] — Restructurations
- [[Problemes de Sante Non Reconnus]]

## Sante

### Malades Longue Duree
- [[Malades Longue Duree]] — 500 000+ personnes
- [[Burnout et Depression]] — Epidemie silencieuse
- [[TMS]] — Troubles musculo-squelettiques
- [[Maladies Chroniques]]

### Mesures Arizona
- [[Sanctions Malades]] — Penalites -2.5%
- [[Taxe Sante]] — Denoncee par Solidaris
- [[Deremboursements]] — IPP, statines

### Statut BIM
- [[BIM]] — Beneficiaire Intervention Majoree
- [[Perte BIM au Premier Euro]] — Effet falaise
- [[Tarifs Sociaux]] — Energie, transports

## Precarite Etudiante

- [[Precarite Etudiante]] — 58% insecurite alimentaire
- [[Etudiants Non-Financables]] — 15 000 exclus
- [[Travail Etudiant 650h]] — Piege vs reussite academique

## Familles Monoparentales

- [[Familles Monoparentales]] — 80% femmes
- [[Cumul Emploi Precaire]] — + charge familiale
- [[Effets de Seuil]] — Premieres victimes

## Chiffres Cles

| Indicateur | Valeur |
|------------|--------|
| Cout inactivite/an | 21-24 Md EUR |
| Personnes inactives | 978 000 |
| Malades longue duree | 500 000+ |
| Deficit secu 2024 | 18.2 Md EUR |
| Projection 2028 | 24.1 Md EUR |
| Taux AROPE | 18.3% |
| Etudiants insecurite | 58% |

## Liens Connexes

**Acteurs concernes** : [[MOC Acteurs]]
**Solutions proposees** : [[MOC ECP]]
**Retour** : [[HOME]]

---

#crises #chomage #sante #precarite #urgence #social
