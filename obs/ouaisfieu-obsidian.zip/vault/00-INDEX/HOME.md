---
title: "Ouaisfieu Knowledge Base"
aliases: [Home, Accueil, Index]
tags: [MOC, index, navigation]
created: 2026-02-03
cssclass: dashboard
---

# OUAISFIEU — Base de Connaissances

> *En Belgique, l'inactivite forcee coute 1 MILLION D'EUROS PAR HEURE.*

## Vision du Projet

**Ouaisfieu** est un projet artisanal de [[Veille Citoyenne]] belge visant la reconnaissance en [[Education Permanente]] par la [[FWB]] d'ici mars 2026.

## Cartes de Contenu (MOC)

### Systeme Belge
- [[MOC Belgique]] — Institutions, particratie, histoire
- [[MOC Crises Sociales]] — Chomage, sante, precarite
- [[MOC Acteurs]] — Allies, neutres, opposants

### Strategie et Ressources  
- [[MOC Financements]] — Sans structure, ASBL, europeen
- [[MOC Technologies]] — Civic tech, standards, OSINT
- [[MOC ECP]] — Economie Contributive Provisionnee

### Projet Ouaisfieu
- [[MOC Ouaisfieu]] — Ecosysteme, strategie, roadmap
- [[MOC Ressources]] — Glossaire, sources, templates

## Dashboard Rapide

| Indicateur | Valeur | Tendance |
|------------|--------|----------|
| Cout inactivite/an | 21-24 Md EUR | Critique |
| Personnes concernees | 978 000 | Stable |
| Deficit secu 2024 | 18.2 Md EUR | Hausse |
| Taux AROPE | 18.3% | Stable |
| Moratoire EP fin | 2028 | Bloque |

## Actions Urgentes

> [!warning] ALERTE — Vague 2 Exclusions
> **Date**: 1er mars 2026
> **Concernes**: 90 000 personnes
> Voir [[Vague 2 Exclusions Chomage]]

### Timeline Immediate
- [ ] T1 2026 : [[Depot Ruling SDA]]
- [ ] T2 2026 : [[Lancement Pilote ARC]]
- [ ] T3 2026 : [[100 Contributeurs ECP]]
- [ ] T4 2026 : [[Decision SDA]]

## Liens Rapides

**Institutions**
[[Coalition Arizona]] | [[Particratie]] | [[Pilarisation]] | [[Lasagne Institutionnelle]]

**Acteurs Cles**
[[Bart De Wever]] | [[Frank Vandenbroucke]] | [[FGTB]] | [[CSC]] | [[SDA]]

**Concepts**
[[Intelligence Citoyenne]] | [[ECP]] | [[DIKW]] | [[Communs Informationnels]]

**Outils**
[[Solid Protocol]] | [[FHIR]] | [[Decidim]] | [[Git Scraping]]

## Structure du Vault

- 00-INDEX/ : Navigation et MOCs
- 01-BELGIQUE/ : Systeme politique belge
- 02-CRISES/ : Problematiques sociales
- 03-ACTEURS/ : Cartographie des acteurs
- 04-FINANCEMENTS/ : Sources et opportunites
- 05-TECHNOLOGIES/ : Stack et outils
- 06-ECP/ : Economie Contributive
- 08-RESSOURCES/ : Glossaire, sources
- 09-JOURNAL/ : Notes de veille

## Tags Principaux

#belgique #particratie #crises #financement #civic-tech #ecp #veille #acteur #institution #juridique #strategie

---

*Licence : CC BY-NC 4.0*
