---
title: "MOC Belgique"
aliases: [Systeme Belge, Politique Belge]
tags: [MOC, belgique, politique, institutions]
created: 2026-02-03
---

# MOC Belgique

> *Le systeme politique belge : une democratie sous tension entre particratie, pilarisation et fragmentation institutionnelle.*

## Institutions

### Structure Federale
- [[Lasagne Institutionnelle]] — Les 6 niveaux de pouvoir
- [[Etat Federal]] — Gouvernement, Chambre, Senat
- [[Regions]] — Wallonie, Flandre, Bruxelles-Capitale
- [[Communautes]] — FWB, Communaute flamande, Germanophone
- [[Provinces]] — Les 10 provinces
- [[Communes]] — 581 entites locales

## Particratie

### Concept Central
- [[Particratie]] — Definition et mecanismes
- [[Case de Tete]] — Effet devolutif sur les elections
- [[Cordon Sanitaire]] — Exclusion de l'extreme-droite
- [[Financement des Partis]] — Verrou contre le renouvellement

### Dysfonctionnements
- [[Citoyen Pigeon]] — Le sentiment d'alienation
- [[Compromis a la Belge]] — Culture de l'opacite
- [[Deficit Democratique]] — Distance electeur/decision

## Histoire et Contexte

### Pilarisation
- [[Pilarisation]] — Verzuiling et ses piliers
- [[Pilier Catholique]] — CDV, Engages, CSC, MC
- [[Pilier Socialiste]] — PS, Vooruit, FGTB, Solidaris
- [[Pilier Liberal]] — MR, Open VLD, CGSLB

### Clivages Fondateurs
- [[Clivage Philosophique]] — Eglise vs Etat
- [[Clivage Socio-economique]] — Capital vs Travail
- [[Clivage Linguistique]] — Centre vs Peripherie

## Coalition Arizona (2025-2029)

- [[Coalition Arizona]] — Composition et programme
- [[Bart De Wever]] — Premier Ministre N-VA
- [[Objectifs Arizona]] — 18 Md EUR economies, 80% emploi
- [[Reformes Sociales Arizona]] — Chomage 24 mois, malades

## Chiffres Cles

| Indicateur | Valeur |
|------------|--------|
| Budget Senat 2025 | 44+ M EUR |
| PIB/habitant UE 2023 | 36 100 EUR |
| Salaire moyen brut | 4 434 EUR/mois |
| Communes | 581 |
| Provinces | 10 |

## Liens Connexes

**Vers les crises** : [[MOC Crises Sociales]]
**Vers les acteurs** : [[MOC Acteurs]]
**Retour** : [[HOME]]

---

#belgique #institutions #particratie #pilarisation #politique
