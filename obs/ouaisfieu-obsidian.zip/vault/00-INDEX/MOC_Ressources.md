---
title: "MOC Ressources"
aliases: [Ressources, Glossaire, Sources]
tags: [MOC, ressources, glossaire, sources, templates]
created: 2026-02-03
---

# MOC Ressources

> *Glossaire, sources de reference et templates pour la veille citoyenne.*

## Glossaire Complet

### A
| Terme | Definition |
|-------|------------|
| [[AROPE]] | At Risk Of Poverty or social Exclusion — Indicateur europeen de precarite |
| [[Article 23]] | Article de la Constitution belge garantissant les droits ESC (standstill) |
| [[ATA]] | Attestation du Travail des Arts — Nouveau statut d'artiste belge |

### B
| Terme | Definition |
|-------|------------|
| [[BAPN]] | Belgian Anti-Poverty Network |
| [[BIM]] | Beneficiaire de l'Intervention Majoree — Statut remboursements majores |

### C
| Terme | Definition |
|-------|------------|
| [[CCPLC]] | Collectif Citoyen pour la Participation Libre et Consciente |
| [[CERV]] | Citizens, Equality, Rights and Values — Programme europeen |
| [[CPAS]] | Centre Public d'Action Sociale — Aide sociale communale |
| [[CSC]] | Confederation des Syndicats Chretiens |

### D-E
| Terme | Definition |
|-------|------------|
| [[Decidim]] | Plateforme open source de democratie participative |
| [[DIKW]] | Data - Information - Knowledge - Wisdom |
| [[ECP]] | Economie Contributive Provisionnee |

### F-G
| Terme | Definition |
|-------|------------|
| [[FGTB]] | Federation Generale du Travail de Belgique |
| [[FHIR]] | Fast Healthcare Interoperability Resources |
| [[FRB]] | Fondation Roi Baudouin |
| [[FWB]] | Federation Wallonie-Bruxelles |

### I-O
| Terme | Definition |
|-------|------------|
| [[ICIJ]] | International Consortium of Investigative Journalists |
| [[INAMI]] | Institut National d'Assurance Maladie-Invalidite |
| [[ONSS]] | Office National de Securite Sociale |
| [[OSINT]] | Open Source Intelligence |

### P-R
| Terme | Definition |
|-------|------------|
| [[Particratie]] | Systeme ou le pouvoir appartient aux partis |
| [[Pilarisation]] | Organisation de la societe belge en piliers |
| [[RIS]] | Revenu d'Integration Sociale — Aide CPAS |
| [[Ruling]] | Decision anticipee du fisc validant un montage juridique |

### S
| Terme | Definition |
|-------|------------|
| [[SDA]] | Service des Decisions Anticipees — Autorite des rulings fiscaux |
| [[SLAPP]] | Strategic Lawsuit Against Public Participation |
| [[Solid]] | Social Linked Data — Protocole de souverainete des donnees |
| [[Standstill]] | Principe interdisant de reduire la protection sociale existante |

## Sources de Reference

### Institutions Belges
- Chambre des Representants : lachambre.be
- Senat : senate.be
- SPF Finances : finances.belgium.be
- Statbel : statbel.fgov.be
- CRISP : vocabulairepolitique.be

### Donnees et Statistiques
- Eurostat : ec.europa.eu/eurostat
- IWEPS : iweps.be
- Open Data Wallonie-Bruxelles : opendata.wb.be

### Academique
- DULBEA (ULB)
- CIRTES (UCLouvain)
- Erudit, Cairn

### Presse
- Le Soir, Le Vif, L'Echo, RTBF
- Revue Politique

### Organisations Citoyennes
- FGTB, CSC, Solidaris
- Ligue des Droits Humains

## Liens Connexes

**Retour** : [[HOME]]

---

#ressources #glossaire #sources #templates #reference
