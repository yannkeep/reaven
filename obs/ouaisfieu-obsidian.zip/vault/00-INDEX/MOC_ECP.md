---
title: "MOC ECP"
aliases: [Economie Contributive Provisionnee, ECP, Ruling Fiscal]
tags: [MOC, ecp, ruling, juridique, pilote, innovation]
created: 2026-02-03
---

# MOC ECP — Economie Contributive Provisionnee

> *24 000 EUR pour prouver qu'une alternative existe. Contre 21 milliards de depenses passives par an.*

## Vision

Transformer les 21-24 milliards EUR/an de depenses passives en investissement actif via un mecanisme de provisionnement differe, permettant aux 978 000 personnes en inactivite contrainte de contribuer SANS PERDRE leurs droits sociaux.

## Cadre Juridique

### Leviers Existants
| Levier | Detail | Plafond/Condition |
|--------|--------|-------------------|
| [[Loi Volontariat 2005]] | Indemnites non imposables | 1 692,51 EUR/an |
| [[VVPR-bis]] | Dividendes taux reduit | 15% au lieu de 30% |
| [[Procedure Ruling SDA]] | Decision anticipee fiscale | Securisation juridique |

### Risques a Securiser
| Risque | Organe | Enjeu |
|--------|--------|-------|
| [[Article 344 CIR 92]] | SPF Finances | Disposition anti-abus |
| [[Requalification ONSS]] | ONSS | Criteres : prestation, remuneration, subordination |
| [[Perte BIM]] | INAMI | Effet falaise au premier euro |

## Cible Principale : SDA

> [!info] Service des Decisions Anticipees
> Seule autorite habilitee a delivrer un ruling fiscal securisant l'ECP.

Voir : [[SDA]], [[Depot Ruling SDA]]

## Projet Pilote ARC

### Objectifs SMART

| Objectif | Indicateur | Deadline |
|----------|------------|----------|
| [[Ruling Fiscal Favorable]] | Decision SDA ecrite | 31/10/2026 |
| [[100 Contributeurs ECP]] | Chartes signees | 15/12/2026 |
| [[Etude Impact DULBEA]] | Rapport ROI social | 30/09/2026 |
| [[Partenariat Paradigm-Athumi]] | Convention Pod Solid | 30/06/2026 |
| [[Couverture Mediatique]] | 3+ articles | 15/09/2026 |

### Timeline

- T1 2026 : Depot ruling SDA
- T2 2026 : Recrutement 50 contributeurs
- T3 2026 : Extension 100 contributeurs
- T4 2026 : Bilan pilote, decision SDA

### Budget
- Total : 24 000 EUR
- Repartition : Avocat, infrastructure, communication, coordination

## Infrastructure Technique

| Composant | Outil | Fonction |
|-----------|-------|----------|
| Donnees personnelles | [[Solid Protocol]] (Pod) | Souverainete contributeur |
| Sante/Social | [[FHIR]] | Pont Social mutuelles |
| Gouvernance | [[Decidim]] | Deliberation liquide |
| Tracabilite | [[Git Scraping]] | Verite administrative |
| Capteurs | [[Sensor.community]] | Science citoyenne |

## Profils Cibles

| Profil | Nombre | Caracteristiques |
|--------|--------|------------------|
| [[Malades Longue Duree]] | 500 000+ | Burnout, TMS, chroniques |
| [[Chomeurs Longue Duree]] | Variable | 50-55 ans, ex-industriels |
| [[Etudiants Precarises]] | — | 58% insecurite alimentaire |
| [[Aidants Proches]] | — | Travail de care invisible |

## Messages Cles

### Accroche
> En Belgique, l'inactivite forcee coute 1 MILLION D'EUROS PAR HEURE. 978 000 personnes sont PAYEES pour ne rien faire. Pas parce qu'elles le veulent. Mais parce que le systeme les PUNIT des qu'elles essaient de contribuer.

### Vers le SDA
> Vous avez le pouvoir de SECURISER l'innovation sociale par un simple ruling.

### Vers Arizona
> L'ECP valorise le travail SANS sanctionner les precaires.

## Liens Connexes

**Contexte** : [[MOC Crises Sociales]]
**Acteurs** : [[MOC Acteurs]]
**Technologies** : [[MOC Technologies]]
**Retour** : [[HOME]]

---

#ecp #ruling #juridique #innovation #pilote #contribution
