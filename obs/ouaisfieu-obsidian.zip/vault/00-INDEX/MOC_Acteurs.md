---
title: "MOC Acteurs"
aliases: [Cartographie Acteurs, Parties Prenantes]
tags: [MOC, acteurs, allies, opposants, institutions]
created: 2026-02-03
---

# MOC Acteurs

> *Cartographie du rapport de forces pour la defense du modele social belge et le deploiement de l'ECP.*

## Allies (Pouvoir 2-4)

### Syndicats — Front Commun
| Acteur | Role | Pouvoir |
|--------|------|---------|
| [[FGTB]] | Syndicat socialiste, leader front commun | 4/5 |
| [[CSC]] | Syndicat chretien, reseau et mobilisation | 4/5 |
| [[CGSLB]] | Syndicat liberal, membre front commun | 3/5 |

### Mutuelles
| Acteur | Role | Pouvoir |
|--------|------|---------|
| [[Solidaris]] | Mutualite socialiste, expertise sante | 3/5 |
| [[MC]] | Mutualite chretienne | 3/5 |

### Reseaux Anti-Pauvrete
| Acteur | Role | Pouvoir |
|--------|------|---------|
| [[BAPN]] | Reseau Belge Lutte Pauvrete | 2/5 |
| [[RWLP]] | Reseau Wallon Lutte Pauvrete | 2/5 |
| [[Ligue Droits Humains]] | ONG, co-requerant recours | 2/5 |

### Opposition Parlementaire
| Acteur | Role | Pouvoir |
|--------|------|---------|
| [[PS]] | Opposition principale (Paul Magnette) | 3/5 |
| [[PTB]] | Gauche radicale, alternatives chiffrees | 2/5 |
| [[Ecolo]] | Verts francophones | 2/5 |

## Neutres (Pouvoir 3-5)

### Cibles Principales ECP
| Acteur | Role | Pouvoir |
|--------|------|---------|
| [[SDA]] | Service Decisions Anticipees — Rulings fiscaux | 5/5 |
| [[ONSS]] | Securite sociale — Requalification salariale | 5/5 |
| [[Cabinet Vandenbroucke]] | Affaires Sociales (Vooruit) | 5/5 |

### Administrations
| Acteur | Role | Pouvoir |
|--------|------|---------|
| [[ONEM]] | Office National Emploi | 3/5 |
| [[INAMI]] | Assurance maladie | 3/5 |
| [[SPF Finances]] | Administration fiscale | 5/5 |

### Collectivites Locales
| Acteur | Role | Pouvoir |
|--------|------|---------|
| [[UVCW]] | Union Villes Communes Wallonnes | 3/5 |
| [[Brulocalis]] | CPAS bruxellois (80M EUR surcout) | 3/5 |

## Opposants (Pouvoir 3-5)

### Coalition Arizona
| Acteur | Role | Pouvoir |
|--------|------|---------|
| [[Bart De Wever]] | Premier Ministre N-VA, architecte | 5/5 |
| [[Georges-Louis Bouchez]] | President MR, orthodoxie budgetaire | 4/5 |
| [[Maxime Prevot]] | President Les Engages | 3/5 |

### Pressions Externes
| Acteur | Role | Pouvoir |
|--------|------|---------|
| [[Commission Europeenne]] | Pression 23 Md EUR deficit | 4/5 |

## Partenaires Techniques ECP

| Acteur | Role | Statut |
|--------|------|--------|
| [[Paradigm]] | Gestionnaire donnees Bruxelles, Solid | Allie 3/5 |
| [[Athumi]] | Gestionnaire donnees Flandre, Solid | Allie 3/5 |
| [[Open Knowledge Belgium]] | Communaute civic tech | Allie 2/5 |

## Liens Connexes

**Contexte** : [[MOC Belgique]]
**Enjeux** : [[MOC Crises Sociales]]
**Retour** : [[HOME]]

---

#acteurs #allies #opposants #syndicats #institutions #cartographie
