---
title: "MOC Technologies"
aliases: [Stack Technique, Outils, Civic Tech]
tags: [MOC, technologies, civic-tech, osint, standards]
created: 2026-02-03
---

# MOC Technologies

> *Infrastructure technique pour l'intelligence citoyenne : souverainete des donnees, interoperabilite et transparence.*

## Standards et Protocoles

### Souverainete des Donnees
- [[Solid Protocol]] — Tim Berners-Lee, Pod personnel
  - Partenaires BE : [[Paradigm]] (Bruxelles), [[Athumi]] (Flandre)
  - Principe : l'utilisateur controle ses donnees

### Interoperabilite Sante/Social
- [[FHIR]] — Fast Healthcare Interoperability Resources
  - Standard HL7 pour echange donnees medicales
  - Application : Pont Social (mutuelles)

### Deliberation et Participation
- [[Decidim]] — Plateforme open source
  - Utilise par : Participation.brussels, Democratie.brussels
  - Fonctions : consultations, budgets participatifs, assemblees

## Veille et Transparence

### Git Scraping
- [[Git Scraping]] — Methode Simon Willison
  - Versioning automatique des donnees publiques
  - Detection des changements administratifs

### OSINT Citoyenne
- [[OSINT]] — Open Source Intelligence
  - [[Bellingcat]] — Pionnier, 40 employes
  - [[OCCRP]] — 11 Md USD amendes/saisies generees
  - Outils : Perplexity.AI, ChatGPT, GitHub

### Science Citoyenne
- [[Sensor.community]] — Capteurs qualite air/bruit
  - Modele decentralise
  - Infrastructure pour [[ECP]] (capteurs citoyens)

## Civic Tech Belgique

| Plateforme | Type | Operateur |
|------------|------|-----------|
| Participation.brussels | Participation citoyenne | Region BXL |
| Democratie.brussels | Decidim | Region BXL |
| MonOpinion | Consultation | SPF BOSA |
| CitizenLab | SaaS participation | 70 clients |
| Open Data Wallonia-Bruxelles | Portail donnees | Regions |

## Infrastructure Ouaisfieu

### Generateurs de Sites Statiques
| Outil | Usage | Themes |
|-------|-------|--------|
| [[Grav CMS]] | Portail ouaisfi.eu | Learn2 |
| [[Hugo]] | Publications dl.ouaisfi.eu | FixIt, Relearn |
| [[Jekyll]] | Documentation GitHub Pages | Just the Docs |

### Hebergement
- [[GitHub Pages]] — Gratuit, zero cout
- Avantages : versioning, contributions ouvertes, transparence

## Modele DIKW

```
SAGESSE (Jugement, decision, action)
    |
CONNAISSANCE (Patterns, insights, comprehension)
    |
INFORMATION (Donnees contextualisees, sens)
    |
DONNEES (Faits bruts, observations)
```

Voir : [[DIKW]], [[Intelligence Citoyenne]]

## Organisations de Reference

### Journalisme d'Investigation
| Organisation | Portee | Impact |
|--------------|--------|--------|
| [[ICIJ]] | 280 journalistes, 105 pays | Panama Papers |
| [[OCCRP]] | Crime organise | 11 Md USD amendes |
| [[Bellingcat]] | OSINT | MH17, Navalny |

### Observatoires Citoyens
| Organisation | Pays | Focus |
|--------------|------|-------|
| [[CRIIRAD]] | France | Radioactivite |
| [[Regards Citoyens]] | France | Transparence parlementaire |
| [[LobbyControl]] | Allemagne | Lobbying |
| [[FragDenStaat]] | Allemagne | Acces documents |
| [[OpenSecrets]] | USA | Argent politique |

## Liens Connexes

**Application** : [[MOC ECP]]
**Projet** : [[MOC Ouaisfieu]]
**Retour** : [[HOME]]

---

#technologies #civic-tech #osint #solid #fhir #decidim #standards
