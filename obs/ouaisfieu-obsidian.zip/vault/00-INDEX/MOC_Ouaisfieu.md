---
title: "MOC Ouaisfieu"
aliases: [Projet Ouaisfieu, Ecosysteme]
tags: [MOC, ouaisfieu, projet, ecosysteme, strategie]
created: 2026-02-03
---

# MOC Ouaisfieu

> *Un projet artisanal de veille citoyenne belge deploye sur une dizaine de plateformes interconnectees.*

## Identite du Projet

### Mission
Contre-democratie informationnelle : produire des communs informationnels au service de la transparence democratique.

### Valeurs
- Transparence totale — Code et sources accessibles
- Zero publicite — Zero tracage
- Cout quasi-nul — Hebergement gratuit GitHub Pages
- Open Source — Licence CC BY-NC 4.0

### Contact
- Email : souad.effek@ouaisfi.eu
- Bluesky : @ouaisfi.eu
- Signature : Cellule Analyse — Ouaisfi.eu

## Architecture Technique

### Portails Principaux
| Site | URL | Technologie |
|------|-----|-------------|
| Hub central | ouaisfi.eu | Grav CMS + Learn2 |
| DOCTech | ouaisfieu.github.io/tech/ | Jekyll + Just the Docs |
| BXL2030 | ouaisfieu.github.io/bxl2030/ | Jekyll + Minimal Mistakes |
| BXL2042 | ouaisfieu.github.io/bxl2042/ | Jekyll |
| Dossiers | ouaisfieu.github.io/dossiers/ | Jekyll + Minimal Mistakes |

### Publications Hugo
| Site | URL | Theme |
|------|-----|-------|
| 11-60 bis | dl.ouaisfi.eu/1160/ | FixIt |
| Biologia | dl.ouaisfi.eu/biologia/ | FixIt |
| EARL | dl.ouaisfi.eu/earl/ | Relearn |

## Contenu Structure

### DOCTech — 4 Blocs
1. Notions : subjectivation, violence, soft power
2. Dossiers : democratie belge, pouvoir d'agir
3. Belgique : pilarisation, particratie, compromis, complexite
4. Et quoi? : autonomie citoyenne

### CCPLC — 6 Axes Strategiques 2025-2026
Collectif Citoyen pour la Participation Libre et Consciente

1. Observer — Veille et monitoring
2. Documenter — Production de contenus
3. Outiller — Developpement d'outils
4. Former — Education citoyenne
5. Connecter — Mise en reseau
6. Evaluer — Mesure d'impact

### Lead-dexing
Methode originale de veille image sur personnalites publiques belges :
- Publication de fiches
- Appel a reaction sur Bluesky via #leaddexing

## Objectif Institutionnel

### Reconnaissance Education Permanente
- Decret : 17 juillet 2003
- Deadline : 31 mars 2026
- Duree : Contrat-programme 5 ans
- Statut : [[Moratoire EP 2026-2028]] — Bloque temporairement

### Conformite Demontree
| Critere | Preuve |
|---------|--------|
| Analyses de societe | 4 dossiers references |
| Regard critique | Contexte, chiffres, pistes d'action |
| Public adulte large | Acces libre, PDF, reseaux federes |
| Citoyennete active | Contributions Git, ateliers-debats |

## Liens Connexes

**Strategie** : [[MOC ECP]]
**Financement** : [[MOC Financements]]
**Retour** : [[HOME]]

---

#ouaisfieu #projet #ecosysteme #strategie #veille #education-permanente
