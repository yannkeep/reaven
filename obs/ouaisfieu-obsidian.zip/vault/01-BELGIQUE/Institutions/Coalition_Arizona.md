---
title: "Coalition Arizona"
aliases: [Gouvernement Arizona, Arizona]
tags: [belgique, politique, coalition, gouvernement, 2025]
created: 2026-02-03
periode: 2025-2029
pm: Bart De Wever
---

# Coalition Arizona

> *Gouvernement federal belge (2025-2029) forme par N-VA, MR, Les Engages, CDV et Vooruit.*

## Composition

| Parti | Famille | Positionnement |
|-------|---------|----------------|
| N-VA | Nationaliste flamand | Centre-droit a droite |
| MR | Liberal francophone | Centre-droit |
| Les Engages | Humaniste (ex-cdH) | Centre |
| CDV | Chretien-democrate flamand | Centre |
| Vooruit | Social-democrate flamand | Centre-gauche |

### Premier Ministre
[[Bart De Wever]] (N-VA) — Architecte ideologique de la coalition

### Ministres Cles
- [[Frank Vandenbroucke]] (Vooruit) — Affaires Sociales et Sante

## Programme et Objectifs

### Objectifs Chiffres

| Objectif | Cible | Horizon |
|----------|-------|---------|
| Economies budgetaires | 18 Md EUR | 2029 |
| Taux d'emploi | 80% | 2030 |
| Differentiel travail/inactivite | +500 EUR | 2026 |
| Reduction deficit UE | 23 Md EUR | 2029 |

### Mesures Phares

#### Chomage
- [[Limitation Chomage 24 Mois]] — Fin de l'assurance illimitee
- [[Vague 2 Exclusions Chomage]] — 90 000 personnes concernees (01/03/2026)
- Activation renforcee et conditionnalite accrue

#### Sante
- [[Sanctions Malades]] — Penalites -2.5% pour malades longue duree
- Deremboursements cibles (IPP, statines)
- Controles renforces de l'incapacite de travail

#### Travail
- Valorisation du travail vs inactivite (+500 EUR differentiel)
- Flexibilisation du marche du travail
- Simplification administrative

## Contexte Budgetaire

### Contrainte Europeenne
La [[Commission Europeenne]] impose un retour sous les 3% de deficit, soit 23 milliards d'economies a realiser d'ici 2029.

### Situation de Depart
| Indicateur | Valeur 2024 |
|------------|-------------|
| Deficit secu sociale | 18,2 Md EUR |
| Dette publique | 105% PIB |
| Taux d'emploi | 72,1% (vs 75,4% UE) |

## Critiques

### Opposition
- [[PS]] — Demantelement du modele social
- [[PTB]] — Alternatives budgetaires (taxe millionnaires, fraude fiscale)
- [[Ecolo]]/Groen — Impact environnemental et social

### Syndicats
Le [[FGTB]], la [[CSC]] et la CGSLB ont forme un front commun contre les reformes sociales.

### Recours Juridiques
- [[Recours Article 23]] — Depose le 29/10/2025 a la Cour Constitutionnelle
- Principe de standstill invoque

## Position sur l'ECP

Le projet [[ECP]] tente de s'aligner avec les objectifs Arizona (valoriser le travail) tout en proposant une alternative non-punitive a l'activation coercitive.

Argument ECP vers Arizona :
> L'ECP valorise le travail SANS sanctionner les precaires. Il transforme 21 Md EUR de depenses passives en investissement actif.

## Voir Aussi

- [[Bart De Wever]]
- [[Frank Vandenbroucke]]
- [[MOC Crises Sociales]]
- [[MOC Acteurs]]

---

#belgique #politique #coalition #gouvernement #arizona

[[MOC Belgique]] | [[HOME]]
