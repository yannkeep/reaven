---
title: "Pilarisation"
aliases: [Verzuiling, Piliers belges]
tags: [belgique, histoire, sociologie, piliers]
created: 2026-02-03
---

# Pilarisation (Verzuiling)

> *Organisation historique de la societe belge en piliers ideologiques englobant l'ensemble de la vie sociale.*

## Definition

La pilarisation (neerlandais : verzuiling) designe le mode d'organisation sociale qui a structure la Belgique du XIXe siecle jusqu'aux annees 1970-80. La societe s'articulait autour de piliers regroupant chacun :

- Des partis politiques
- Des syndicats
- Des mutuelles
- Des ecoles
- Des medias
- Des associations culturelles et sportives

Un citoyen naissait, etait eduque, travaillait, se soignait et mourait au sein de son pilier.

## Les Trois Piliers Historiques

### Pilier Catholique
| Composante | Organisation |
|------------|--------------|
| Partis | PSC - CDV, cdH - Les Engages |
| Syndicat | [[CSC]] |
| Mutuelle | MC |
| Mouvement | MOC |

### Pilier Socialiste
| Composante | Organisation |
|------------|--------------|
| Partis | [[PS]], Vooruit |
| Syndicat | [[FGTB]] |
| Mutuelle | [[Solidaris]] |

### Pilier Liberal
| Composante | Organisation |
|------------|--------------|
| Partis | MR, Open VLD |
| Syndicat | CGSLB |
| Mutuelle | Mutualites Liberales |

## Les Trois Clivages Fondateurs

### 1. Clivage Philosophique (Eglise / Etat)
- Question scolaire (guerre scolaire)
- Laicite vs confessionnalisme
- Resolu par le Pacte scolaire (1958)

### 2. Clivage Socio-economique (Capital / Travail)
- Question ouvriere
- Naissance des syndicats et mutuelles
- Compromis social belge (Pacte social 1944)

### 3. Clivage Linguistique (Centre / Peripherie)
- Francophone vs neerlandophone
- Frontiere linguistique (1963)
- Federalisation progressive (1970-2011)

## Declin de la Pilarisation

### Erosion Sociologique
A partir des annees 1960-70 :
- Secularisation de la societe
- Mobilite sociale accrue
- Individualisation des parcours
- Medias de masse nationaux

### Survie Structurelle
Paradoxalement, si les citoyens ne vivent plus dans leur pilier, les structures organisationnelles ont survecu :
- Les partis restent heritiers des piliers
- Les syndicats et mutuelles conservent leur affiliation
- Le financement public perpetue ces structures

## Consequences Contemporaines

### La [[Particratie]]
La culture de negociation entre elites des piliers s'est transformee en particratie : les presidents de partis negocient des compromis opaques.

### Le Compromis a la Belge
L'habitude de negocier entre familles produit des solutions complexes, souvent incomprehensibles pour le citoyen.

### Fragmentation Institutionnelle
La gestion du clivage linguistique a produit la lasagne institutionnelle : 6 parlements, 6 gouvernements, pour 11 millions d'habitants.

## Voir Aussi

- [[Particratie]]
- [[Coalition Arizona]]
- [[FGTB]], [[CSC]]

---

#belgique #histoire #sociologie #piliers #verzuiling

[[MOC Belgique]] | [[HOME]]
