---
title: "ECP"
aliases: [Economie Contributive Provisionnee, Provisionnement Differe]
tags: [concept, ecp, innovation, juridique, contribution]
created: 2026-02-03
budget_pilote: 24000
cible_contributeurs: 100
---

# ECP — Economie Contributive Provisionnee

> *Mecanisme permettant aux personnes en inactivite contrainte de contribuer a la societe SANS perdre leurs droits sociaux, via un provisionnement differe de la valeur creee.*

## Vision

Transformer 21-24 milliards EUR/an de depenses passives en investissement actif via un projet pilote de 24 000 EUR.

```
AUJOURD'HUI                  AVEC L'ECP
-----------                  ----------

Inactivite forcee            Contribution active
21-24 Md EUR depenses        21-24 Md EUR investis
978 000 assistes             978 000 contributeurs
Perte de competences         Capital humain valorise
Stigmatisation               Reconnaissance
```

## Le Mecanisme

### Principe du Provisionnement Differe
1. Le contributeur realise des missions (science citoyenne, documentation, formation...)
2. La valeur creee est provisionnee dans une SRL (pas distribuee)
3. Le contributeur conserve ses droits sociaux (BIM, allocations)
4. La distribution intervient plus tard, quand il sort de la precarite
5. Un ruling fiscal securise l'ensemble

### Pourquoi Ca Marche (Juridiquement)

| Element | Justification |
|---------|---------------|
| Pas de revenu immediat | Le provisionnement n'est pas un flux vers le contributeur |
| Pas de subordination | Missions librement choisies, pas de lien salarial |
| Alignement Loi Volontariat 2005 | Plafond 1 692 EUR/an respecte pour les indemnites |
| Finalite sociale | Pas d'optimisation fiscale personnelle |

## Cadre Juridique

### Leviers Mobilises
| Levier | Usage |
|--------|-------|
| Loi Volontariat 2005 | Indemnites non imposables (1 692 EUR/an) |
| VVPR-bis | Dividendes a 15% (si distribution future) |
| Procedure Ruling SDA | Validation du montage |
| SRL | Vehicule de provisionnement |

### Risques a Securiser
| Risque | Parade |
|--------|--------|
| Article 344 CIR 92 | Demontrer finalite sociale |
| Requalification ONSS | Absence de subordination |
| Perte BIM | Ruling confirmant non-revenu |

## Projet Pilote ARC

### Caracteristiques
| Parametre | Valeur |
|-----------|--------|
| Budget | 24 000 EUR |
| Contributeurs cibles | 100+ |
| Duree | 12-18 mois |
| Horizon | 2026-2027 |

### Types de Missions

1. Science Citoyenne
   - Capteurs qualite air (Sensor.community)
   - Mesures environnementales

2. Documentation
   - Fiches pedagogiques
   - Veille legislative

3. Formation par les Pairs
   - Ateliers numeriques
   - Education citoyenne

4. Gouvernance Participative
   - Participation Decidim
   - Coordination de projets

### Objectifs SMART

| Objectif | Indicateur | Deadline |
|----------|------------|----------|
| Ruling favorable | Decision SDA ecrite | 31/10/2026 |
| 100 contributeurs | Chartes signees | 15/12/2026 |
| Etude d'impact | Rapport DULBEA | 30/09/2026 |
| Partenariat tech | Convention Paradigm/Athumi | 30/06/2026 |
| Visibilite | 3+ articles medias | 15/09/2026 |

## Infrastructure Technique

| Composant | Outil | Role |
|-----------|-------|------|
| Donnees personnelles | [[Solid Protocol]] | Souverainete contributeur |
| Interoperabilite sante | FHIR | Pont Social mutuelles |
| Gouvernance | Decidim | Deliberation liquide |
| Tracabilite | Git Scraping | Verite administrative |
| Capteurs | Sensor.community | Science citoyenne |

## Profils Cibles

| Profil | Nombre | Caracteristiques |
|--------|--------|------------------|
| Malades longue duree | 500 000+ | Burnout, TMS, chroniques |
| Chomeurs longue duree | Variable | 50-55 ans, ex-industriels |
| Etudiants precarises | — | 58% insecurite alimentaire |
| Aidants proches | — | Travail de care invisible |

## Messages Cles

### Accroche
> En Belgique, l'inactivite forcee coute 1 MILLION D'EUROS PAR HEURE. 978 000 personnes sont PAYEES pour ne rien faire. Pas parce qu'elles le veulent. Mais parce que le systeme les PUNIT des qu'elles essaient de contribuer.

### Vers le SDA
> Vous avez le pouvoir de SECURISER l'innovation sociale par un simple ruling.

### Vers Arizona
> L'ECP valorise le travail SANS sanctionner les precaires.

### Vers les Precaires
> Vous pouvez contribuer SANS perdre vos droits. La valeur que vous creez vous appartient.

## Voir Aussi

- [[MOC ECP]]
- [[Piege Institutionnel]]
- [[SDA]]
- [[BIM]]
- [[Solid Protocol]]

---

#concept #ecp #innovation #juridique #contribution

[[MOC ECP]] | [[HOME]]
