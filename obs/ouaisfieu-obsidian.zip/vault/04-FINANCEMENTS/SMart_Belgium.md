---
title: "SMart Belgium"
aliases: [SMart, Societe Mutuelle pour Artistes]
tags: [financement, structure, facturation, cooperative]
created: 2026-02-03
type: cooperative
cout: 6.5%
---

# SMart Belgium

> *Cooperative permettant de facturer des prestations sans creer de structure juridique, avec protection sociale complete.*

## Identite

| Attribut | Valeur |
|----------|--------|
| Nom complet | Societe Mutuelle pour Artistes |
| Type | Cooperative d'activites |
| Fondation | 1998 (Belgique) |
| Membres | 35 000 en Belgique |
| Reseau | 9 pays europeens |

## Fonctionnement

### Principe
SMart agit comme employeur pour ses membres :
1. Le membre realise une prestation (formation, conference, consulting...)
2. SMart facture le client au nom du membre
3. SMart verse un salaire au membre
4. Le membre beneficie de la protection sociale des salaries

### Avantages
| Avantage | Detail |
|----------|--------|
| Pas de structure | Pas besoin de creer ASBL ou societe |
| Protection sociale | Chomage, pension, maladie |
| Paiement garanti | 7 jours apres prestation |
| Gestion admin | Facturation, TVA, comptabilite incluses |
| Assurances | RC professionnelle, accidents du travail |

### Cout
- Environ 6,5% du montant facture (incluant toute la gestion)
- Cotisations sociales en plus (comme tout salarie)

## Application pour Ouaisfieu

### Activites Facturables
| Activite | Tarif Indicatif |
|----------|-----------------|
| Formations | 500-2 000 EUR/jour |
| Conferences | 300-2 000 EUR |
| Consulting | 400-800 EUR/jour |
| Licensing contenus pedagogiques | 1 000-10 000 EUR |

### Cas d'Usage
Un projet comme Ouaisfieu peut via SMart :
- Facturer des formations a des ASBL, communes, universites
- Realiser des missions de conseil en veille citoyenne
- Monetiser des contenus pedagogiques
- Recevoir des honoraires de conferences

### Avantage Immediat
> Pas besoin d'attendre la creation d'une ASBL pour generer des revenus d'activite.

## Limites

| Limite | Detail |
|--------|--------|
| Cout | 6,5% + cotisations = environ 50% du brut en net |
| Pas de patrimoine | L'argent passe, ne s'accumule pas |
| Dependance | Relation de salarie avec SMart |

## Articulation avec l'ECP

### Complementarite
- SMart = revenus d'activite immediats
- ECP = contributions provisionnees (differees)

### Attention
Les revenus SMart sont des salaires qui :
- Comptent pour les plafonds BIM
- Peuvent faire perdre des allocations
- Sont soumis a l'impot progressif

L'ECP vise justement a creer un mecanisme different du salariat SMart.

## Voir Aussi

- [[MOC Financements]]
- [[ECP]]
- [[FRB Compte de Projet]]

## Contact

- Site : smartbe.be
- Bruxelles : Rue Emile Feron 70, 1060

---

#financement #structure #facturation #cooperative #smart

[[MOC Financements]] | [[HOME]]
