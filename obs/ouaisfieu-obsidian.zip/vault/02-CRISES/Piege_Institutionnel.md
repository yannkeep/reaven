---
title: "Piege Institutionnel"
aliases: [Trappe a inactivite, Paradoxe belge]
tags: [crises, social, systeme, precarite]
created: 2026-02-03
---

# Piege Institutionnel

> *Le systeme belge INDEMNISE l'inactivite totale mais PENALISE toute tentative de contribution.*

## Le Paradoxe Central

```
INACTIVITE TOTALE          TENTATIVE DE CONTRIBUTION
-----------------          -------------------------

OK Allocations             NON Perte allocations
OK Statut BIM              NON Perte BIM
OK Tarifs sociaux          NON Perte tarifs sociaux
OK Remboursements          NON Perte remboursements

COUT : 0 EUR               COUT : > revenu gagne

RESULTAT : Rester inactif est ECONOMIQUEMENT RATIONNEL
```

## Mecanisme : Le Taux Marginal Effectif superieur a 100%

### Definition
Le taux marginal effectif mesure combien un euro gagne coute reellement en termes de perte d'aides et de statuts.

### En Belgique
Pour les personnes precaires, ce taux depasse souvent 100% :
- 1 EUR gagne = perte du statut [[BIM]]
- Perte BIM = perte des tarifs sociaux energie
- Perte tarifs sociaux = +500-1000 EUR/an de charges
- Resultat : gagner 1 EUR fait perdre plusieurs centaines d'euros

### L'Effet Falaise
Contrairement a un systeme progressif, la Belgique utilise des seuils binaires :
- En dessous du seuil = tous les avantages
- Au-dessus = perte totale et immediate

## Chiffres du Piege

| Indicateur | Valeur |
|------------|--------|
| Personnes en inactivite contrainte | 978 000 |
| Cout annuel de l'inactivite | 21-24 Md EUR |
| Cout horaire | 1 M EUR/heure |
| Deficit secu sociale 2024 | 18,2 Md EUR |
| Projection deficit 2028 | 24,1 Md EUR |

## Causes Structurelles

### 1. Absence de Statut Hybride
Le droit belge ne connait que :
- Salarie (contrat de travail)
- Independant (statut social des independants)
- Volontaire strict (loi 2005, plafond 1 692 EUR/an)
- Inactif (allocataire)

Il n'existe aucun statut pour les formes hybrides de contribution citoyenne.

### 2. Systeme Binaire
Le marche du travail belge est concu de facon binaire :
- CDI a temps plein = norme
- Tout le reste = suspect ou precaire

### 3. Cloisonnement Administratif
Chaque administration (SPF, [[ONSS]], [[ONEM]], [[INAMI]]) gere ses propres regles sans coordination.

### 4. Ideologie d'Activation Coercitive
L'approche dominante postule que seule la SANCTION incite a l'emploi.
Cette vision ignore les freins structurels reels : sante, formation, garde d'enfants, transport, logement.

## Populations Concernees

| Profil | Nombre | Specificite |
|--------|--------|-------------|
| [[Malades Longue Duree]] | 500 000+ | Burnout, TMS, chroniques |
| Chomeurs longue duree | Variable | 50-55 ans, restructurations |
| Familles monoparentales | 80% femmes | Cumul precarites |
| Etudiants precarises | 58% insec. alim. | Piege travail etudiant |
| Aidants proches | Non comptabilises | Travail invisible |

## Solutions Proposees

### L'[[ECP]] — Economie Contributive Provisionnee
Mecanisme de provisionnement differe permettant de contribuer sans perdre ses droits :
- Contribution = investissement, pas revenu immediat
- Accumulation dans une SRL
- Distribution differee au-dela du seuil de precarite

### Autres Pistes
- Suppression des effets de seuil (progressivite)
- Coordination inter-administrations
- Statut de contributeur citoyen
- Revenu de base universel (debat)

## Voir Aussi

- [[BIM]]
- [[ECP]]
- [[MOC Crises Sociales]]
- [[Coalition Arizona]]

---

#crises #systeme #precarite #piege #social

[[MOC Crises Sociales]] | [[HOME]]
